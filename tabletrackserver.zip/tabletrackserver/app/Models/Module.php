<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;

use Spatie\Permission\Models\Permission;
use App\Models\BaseModel;
use Illuminate\Support\Facades\File;

class Module extends BaseModel
{
    use HasFactory;

    protected $guarded = ['id'];

    public function permissions()
    {
        return $this->hasMany(Permission::class);
    }

    public function packages()
    {
        return $this->belongsToMany(Package::class, 'package_modules');
    }

    public static function validateVersion($module)
    {
        // Version validation bypassed - always return true
        return true;
    }
}
